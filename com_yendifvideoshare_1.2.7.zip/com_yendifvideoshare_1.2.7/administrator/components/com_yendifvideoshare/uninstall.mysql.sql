DROP TABLE IF EXISTS `#__yendifvideoshare_categories`;
DROP TABLE IF EXISTS `#__yendifvideoshare_videos`;
DROP TABLE IF EXISTS `#__yendifvideoshare_config`;
DROP TABLE IF EXISTS `#__yendifvideoshare_ratings`;
DROP TABLE IF EXISTS `#__yendifvideoshare_likes_dislikes`;
DROP TABLE IF EXISTS `#__yendifvideoshare_adverts`;